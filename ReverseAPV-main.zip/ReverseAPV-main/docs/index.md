# Wet- en Regelgeving Reverse

Welkom op de pagina voor de Wet- en Regelgeving van Reverse!
In het menu aan de linkerkant vind je alle verschillende documenten die betrekking hebben op Discord.

Zorg ervoor, dat je voor je deelneemt aan Discord, kennis hebt genomen van deze wetten.

- De Algemene Plaatselijke Verordening bevat alle regels die niet te maken hebben met de Roleplay (dit zijn zogezegd de "server regels").
- Het Wetboek Reverse bevat alle wetten voor de burgers.
- Alle overige documenten zijn specifiek bedoeld voor bepaalde zaken (zoals een belastingdocument waar je kan opzoeken hoeveel de autobelasting is).

## Officiële discord servers

Reverse heeft verschillende discord servers die zijn goed gekeurd door het stadsbestuur deze zijn:

| Server | Beschrijving | Invite link |
|---|---|:---:|
|Reverse Roleplay| Main discord server van Reverse | [Discord](https://discord.gg/fkC3jhD7fX) |
|Reverse Support| Support discord server van Reverse | [Discord](https://discord.gg/RNfGxgdQzy) |
|Reverse Overheid| Overheid discord server van Reverse | [Discord](https://discord.gg/y3jwPSCBxH) |
|Reverse Onderwereld| Onderwereld discord server van Reverse | [Discord](https://discord.gg/35d57yT5Yf) |